import express from 'express'
import jwt from 'jsonwebtoken'
const jwtsecret = process.env.JWT_SECRETKEY;
export function authentication(req,res,next){
    const token = req.header(tokenKey);
    const verifying = jwt.verify(token, jwtsecret);
    if(verifying){
        res.send('successfully logged in')
        next();
    }else{
        res.send('unauthorized user')
    }
}

const storage = multer({
    dest:'/upload',
    filename:(req, file, callback) =>{
        callback(null, file.originalname)
    }
})
export var upload = multer({storage:storage}).single('image_upload')



