import express from 'express'
import jwt from 'jsonwebtoken'
const jwtsecret = process.env.JWT_SECRETKEY
import bcrypt from 'bcrypt'




export function loginController(req, res) {
    let { _id, email, password } = req.body

    const generateToken = jwt.sign({ _id: _id, emailId: email }, jwtsecret)
    console.log('user logged in....')
    res.send({ token: generateToken, data: result })
}

export function signupcontroller(req, res) {

    const payload = req.body;
    let hashPassword = bcrypt.hash(req.body.password,10);
    //save into databse 
    console.log('user created successfully')
}
export function uploaimagecontroller(req, res) {

  
    console.log('Image uploaded successfully...........')
}
