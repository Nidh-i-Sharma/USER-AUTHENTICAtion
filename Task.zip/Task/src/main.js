import express from 'express'
import { loginController,signupcontroller } from './controller/signController';
import { authentication } from './middleware/authentication';
import { upload } from './middleware/authentication';

const app = express();
const router = express.Router();

router.get('/signin',loginController);
router.post('/signup',authentication,signupcontroller)
router.post('/uploadimage',upload,uploaimagecontroller)

app.listen(8080,()=>{
    console.log('serer is listenning....')
})